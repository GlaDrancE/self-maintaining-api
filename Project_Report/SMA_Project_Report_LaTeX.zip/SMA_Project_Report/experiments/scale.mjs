// Scalability: time each detection stage against synthetic specs of growing size.
import { writeFileSync } from 'node:fs';
import { resolveRefs } from '/home/claude/repo/sma/src/watcher.mjs';
import { applyRules } from '/home/claude/repo/sma/src/rules.mjs';
import { unexplainedDeltas } from '/home/claude/repo/sma/src/classify.mjs';
import { diff } from '/home/claude/repo/sma/src/diff.mjs';
function make(n, mutate = false) {
  const schemas = {}; const paths = {};
  for (let i = 0; i < n; i++) {
    schemas[`R${i}`] = { type: 'object', required: ['id'], properties: Object.fromEntries(Array.from({ length: 8 }, (_, j) => [`f${j}`, { type: j % 2 ? 'string' : 'integer', description: `field ${j}` }]).concat([['id', { type: 'integer' }], ['status', { type: 'string', enum: ['a', 'b', 'c'] }]])) };
    paths[`/r${i}`] = {
      get: { operationId: `list${i}`, parameters: [{ name: 'limit', in: 'query', schema: { type: 'integer' } }, { name: 'cursor', in: 'query', schema: { type: 'string' } }], responses: { 200: { description: 'ok', content: { 'application/json': { schema: { type: 'array', items: { $ref: `#/components/schemas/R${i}` } } } } } } },
      post: { operationId: `create${i}`, requestBody: { content: { 'application/json': { schema: { $ref: `#/components/schemas/R${i}` } } } }, responses: { 201: { description: 'ok', content: { 'application/json': { schema: { $ref: `#/components/schemas/R${i}` } } } } } },
    };
    paths[`/r${i}/{id}`] = { get: { operationId: `get${i}`, parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'integer' } }], responses: { 200: { description: 'ok', content: { 'application/json': { schema: { $ref: `#/components/schemas/R${i}` } } } } } } };
  }
  const spec = { openapi: '3.0.3', info: { title: 'S', version: '1' }, components: { schemas, securitySchemes: { k: { type: 'apiKey', in: 'header', name: 'X' } } }, paths };
  if (mutate) { // ~1% of resources change: rename a param, drop a field, add required param
    for (let i = 0; i < n; i += 100) {
      paths[`/r${i}`].get.parameters[0].name = 'pageSize';
      delete schemas[`R${i}`].properties.f1;
      paths[`/r${i}/{id}`].get.parameters.push({ name: 'expand', in: 'query', required: true, schema: { type: 'string' } });
    }
  }
  return spec;
}
const med = (a) => [...a].sort((x, y) => x - y)[Math.floor(a.length / 2)];
const rows = [];
for (const n of [10, 25, 50, 100, 250, 500, 1000, 2000, 4000]) {
  const T = { resolve: [], rules: [], diff: [], leftovers: [] }; let meta;
  for (let rep = 0; rep < 5; rep++) {
    const a0 = make(n), b0 = make(n, true);
    let t = performance.now(); const a = resolveRefs(a0); const b = resolveRefs(b0); T.resolve.push((performance.now() - t) / 2);
    t = performance.now(); const hits = applyRules(a, b); T.rules.push(performance.now() - t);
    t = performance.now(); const d = diff(a, b); T.diff.push(performance.now() - t);
    t = performance.now(); const left = unexplainedDeltas(a, b, hits); T.leftovers.push(performance.now() - t);
    meta = { ops: n * 3, bytes: JSON.stringify(a).length, hits: hits.length, breaking: hits.filter((h) => h.severity === 'breaking').length, deltas: d.length, left: left.length };
  }
  const row = { n, ...meta, resolveMs: med(T.resolve), rulesMs: med(T.rules), diffMs: med(T.diff), leftoverMs: med(T.leftovers), heapMB: process.memoryUsage().heapUsed / 1e6 };
  rows.push(row); console.log(JSON.stringify(row));
}
writeFileSync('/home/claude/exp/scale_results.json', JSON.stringify(rows, null, 1));
