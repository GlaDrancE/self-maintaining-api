// Call-site detection benchmark: generate a labelled JS corpus, then compare
// (A) sma's ts-morph AST scanner, (R1) grep for path strings, (R2) grep for HTTP call + path on one line.
import { mkdirSync, writeFileSync, rmSync, readFileSync, readdirSync } from 'node:fs';
import { join } from 'node:path';
const SMA = process.argv[2]; const DIR = process.argv[3]; const NFILES = Number(process.argv[4] ?? 40); const OUT = process.argv[5];
const { scan, shape } = await import(join(SMA, 'src/inventory.mjs'));
let seed = 7; const rnd = () => ((seed = (seed * 1103515245 + 12345) % 2147483648) / 2147483648); const pick = (a) => a[Math.floor(rnd() * a.length)];
const RES = ['widgets', 'orders', 'users', 'invoices'];
rmSync(DIR, { recursive: true, force: true }); mkdirSync(DIR, { recursive: true });
const truth = [];
// statement templates: [label, method, pathShape, code(r)]; label: http | unresolved-true | miss-true | neg
const T = [
  ['http', 'GET', (r) => `/${r}`, (r) => `  const a = await fetch(\`\${BASE}/${r}\`);`],
  ['http', 'GET', (r) => `/${r}/{}`, (r) => `  const a = await fetch(\`\${BASE}/${r}/\${id}\`);`],
  ['http', 'GET', (r) => `/${r}`, (r) => `  const a = await fetch('https://api.example.com/${r}');`],
  ['http', 'POST', (r) => `/${r}`, (r) => `  const a = await fetch(\`\${BASE}/${r}\`, { method: 'POST', body: JSON.stringify(x) });`],
  ['http', 'GET', (r) => `/${r}`, (r) => `  const a = await fetch(\`\${BASE}/${r}?limit=\${n}&page=\${p}\`);`],
  ['http', 'GET', (r) => `/${r}/{}`, (r) => `  const a = await axios.get(\`\${BASE}/${r}/\${id}\`);`],
  ['http', 'POST', (r) => `/${r}`, (r) => `  const a = await axios.post(\`\${BASE}/${r}\`, x);`],
  ['http', 'PUT', (r) => `/${r}/{}`, (r) => `  const a = await axios.put(\`\${BASE}/${r}/\${id}\`, x);`],
  ['http', 'DELETE', (r) => `/${r}/{}`, (r) => `  const a = await got.delete(\`\${BASE}/${r}/\${id}\`);`],
  ['http', 'PATCH', (r) => `/${r}/{}`, (r) => `  const a = await ky.patch(\`\${BASE}/${r}/\${id}\`, { json: x });`],
  ['http', 'GET', (r) => `/${r}`, (r) => `  const a = await request(\`\${BASE}/${r}\`);`],
  ['http', 'POST', (r) => `/${r}`, (r) => `  const a = await axios({ url: \`\${BASE}/${r}\`, method: 'post', data: x });`],
  ['unresolved-true', 'GET', (r) => `/${r}`, (r) => `  const a = await fetch(BASE + '/${r}');`],
  ['unresolved-true', 'GET', (r) => `/${r}`, (r) => `  const u = \`\${BASE}/${r}\`; const a = await fetch(u);`],
  ['miss-true', 'GET', (r) => `/${r}`, (r) => `  const a = await this.http.get(\`\${BASE}/${r}\`);`],
  ['neg', null, null, (r) => `  // TODO: fetch('/${r}') once the endpoint is stable`],
  ['neg', null, null, (r) => `  console.log('calling /${r} now');`],
  ['neg', null, null, (r) => `  const a = await fetch('https://status.other.org/${r}');`],
  ['neg', null, null, (r) => `  logger.info(\`\${BASE}/${r} responded\`);`],
  ['neg', null, null, (r) => `  const route = '/${r}/' + id;`],
  ['neg', null, null, (r) => `  const doc = { href: '/api/${r}', label: 'fetch ${r}' };`],
];
const WEIGHT = T.map(([l]) => (l === 'http' ? 3 : l === 'neg' ? 2 : 1));
const bag = T.flatMap((t, i) => Array(WEIGHT[i]).fill(t));
let fnCount = 0;
for (let f = 0; f < NFILES; f++) {
  const lines = ["const BASE = 'https://api.example.com';", 'const id = 1, n = 10, p = 1, x = {};', ''];
  const wrappers = [];
  const nfn = 2 + Math.floor(rnd() * 3);
  for (let k = 0; k < nfn; k++) {
    const fname = `op${fnCount++}`;
    lines.push(`export async function ${fname}() {`);
    let wrapped = null;
    const nstmt = 1 + Math.floor(rnd() * 3);
    for (let s = 0; s < nstmt; s++) {
      const [label, method, pathFn, code] = pick(bag); const r = pick(RES);
      lines.push(code(r));
      truth.push({ file: `f${f}.js`, line: lines.length, label, method, path: pathFn ? pathFn(r) : null, fn: fname });
      if (label === 'http' && !wrapped) wrapped = { method, path: pathFn(r) };
    }
    lines.push('  return null;', '}', '');
    if (wrapped) wrappers.push({ fname, ...wrapped });
  }
  writeFileSync(join(DIR, `f${f}.js`), lines.join('\n') + '\n');
  // consumer file: one-hop callers and two-hop callers of this file's wrappers
  if (wrappers.length) {
    const c = [`import { ${wrappers.map((w) => w.fname).join(', ')} } from './f${f}.js';`, ''];
    for (const w of wrappers) {
      c.push(`export async function use_${w.fname}() {`);
      c.push(`  return ${w.fname}();`);
      truth.push({ file: `c${f}.js`, line: c.length, label: 'caller1', method: w.method, path: w.path });
      c.push('}', '');
    }
    c.push('export async function main() {');
    for (const w of wrappers) { c.push(`  await use_${w.fname}();`); truth.push({ file: `c${f}.js`, line: c.length, label: 'caller2', method: w.method, path: w.path }); }
    c.push('}', '');
    writeFileSync(join(DIR, `c${f}.js`), c.join('\n') + '\n');
  }
}
// --- method A: sma
const t0 = performance.now();
const { sites, unresolved } = scan({ repoPath: DIR, apis: [{ name: 'ex', baseUrl: 'https://api.example.com' }] });
const msA = performance.now() - t0;
// --- regex baselines
const t1 = performance.now();
const R1 = [], R2 = [];
const pathRe = /['"`][^'"`]*\/(widgets|orders|users|invoices)\b[^'"`]*['"`]/;
const callRe = /\b(fetch|axios|got|ky|request)\s*[.(]/;
for (const f of readdirSync(DIR)) {
  readFileSync(join(DIR, f), 'utf8').split('\n').forEach((ln, i) => {
    const m = ln.match(pathRe); if (!m) return;
    const verb = (ln.match(/\.(get|post|put|patch|delete)\s*\(/) ?? ln.match(/method:\s*'(\w+)'/))?.[1]?.toUpperCase() ?? 'GET';
    const p = (ln.match(/\/(widgets|orders|users|invoices)(\/\$\{[^}]*\})?/) ?? [])[0]?.replace(/\$\{[^}]*\}/, '{}');
    const hit = { file: f, line: i + 1, method: verb, path: p };
    R1.push(hit); if (callRe.test(ln)) R2.push(hit);
  });
}
const msR = performance.now() - t1;
// --- scoring
const key = (x) => `${x.file}:${x.line}`;
const positives = truth.filter((t) => ['http', 'unresolved-true', 'miss-true', 'caller1', 'caller2'].includes(t.label));
function score(name, found, ms, unres = []) {
  const F = new Map(found.map((x) => [key(x), x])); const U = new Set(unres.map(key));
  const T = new Map(truth.map((t) => [key(t), t]));
  let tp = 0, fp = 0, attrOk = 0; const byLabel = {};
  for (const [k, x] of F) { const t = T.get(k); if (t && t.label !== 'neg') { tp++; if (t.method === x.method && shape(t.path) === shape(x.path ?? '')) attrOk++; } else fp++; }
  for (const t of truth) { const b = (byLabel[t.label] ??= { n: 0, found: 0, flaggedUnresolved: 0 }); b.n++; if (F.has(key(t))) b.found++; if (U.has(key(t))) b.flaggedUnresolved++; }
  const fn = positives.filter((t) => !F.has(key(t))).length;
  const P = tp / (tp + fp), R = tp / (tp + fn);
  return { method: name, reported: F.size, tp, fp, fn, precision: P, recall: R, f1: (2 * P * R) / (P + R), attributionAccuracy: attrOk / tp, ms, byLabel };
}
const res = { files: readdirSync(DIR).length, statements: truth.length, positives: positives.length, labels: truth.reduce((a, t) => ((a[t.label] = (a[t.label] ?? 0) + 1), a), {}),
  results: [score('sma AST (ts-morph)', sites, msA, unresolved), score('R1 grep path strings', R1, msR), score('R2 grep call+path', R2, msR)],
  unresolvedReported: unresolved.length };
writeFileSync(OUT, JSON.stringify(res, null, 2));
console.log(JSON.stringify(res, null, 1));
