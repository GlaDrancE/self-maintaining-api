import json, numpy as np
from style import *
E='/home/claude/exp/'
# ---- G: scaling (synthetic)
rows=json.load(open(E+'scale_results.json'))
ops=np.array([r['ops'] for r in rows]); stages=[('resolveMs','Reference resolution'),('diffMs','Structural diff'),('rulesMs','Rule engine'),('leftoverMs','Leftover computation')]
fits={}
fig,ax=plt.subplots(figsize=(6.2,3.6))
for i,(k,l) in enumerate(stages):
    t=np.array([r[k] for r in rows]); b1,b0=np.polyfit(ops,t,1); pred=b0+b1*ops; r2=1-((t-pred)**2).sum()/((t-t.mean())**2).sum()
    # log-log slope
    sl=np.polyfit(np.log(ops),np.log(t),1)[0]
    fits[k]=dict(b0=b0,b1=b1,r2=r2,loglog=sl)
    ax.plot(ops,t,marker='o',color=C[i],label=f'{l} (slope {sl:.2f})')
ax.set_xscale('log'); ax.set_yscale('log'); ax.set_xlabel('Specification size (operations, log scale)'); ax.set_ylabel('Median time per run (ms, log scale)')
ax.legend(frameon=False,loc='upper left')
save(fig,'g_scale_loglog')
tot=np.array([r['resolveMs']*2+r['diffMs']+r['rulesMs']+r['leftoverMs'] for r in rows])
b1,b0=np.polyfit(ops,tot,1); pred=b0+b1*ops; r2=1-((tot-pred)**2).sum()/((tot-tot.mean())**2).sum()
fits['total']=dict(b0=b0,b1=b1,r2=r2)
fig,ax=plt.subplots(figsize=(6.2,3.4))
ax.plot(ops,tot,'o',color=C[0],label='Measured (median of 5 runs)')
xx=np.linspace(0,ops.max(),100); ax.plot(xx,b0+b1*xx,color=C[1],label=f'Linear model t = {b0:.1f} + {b1:.3f} n   (R² = {r2:.4f})')
ax.set_xlabel('Specification size n (operations)'); ax.set_ylabel('Detection time t (ms)'); ax.legend(frameon=False)
save(fig,'g_scale_fit')
json.dump(fits,open(E+'scale_fits.json','w'),indent=1)
print(json.dumps(fits,indent=1))
# ---- G: mutation sma vs naive
m=json.load(open(E+'mutation_summary.json'))
labels=['Precision','Recall','F1 score','Accuracy']; ks=['P','R','F1','Acc']
fig,ax=plt.subplots(figsize=(6.2,3.2)); x=np.arange(4); w=0.36
for j,(name,key) in enumerate([('sma rule engine','sma'),('Naive structural diff','naive')]):
    v=[m[key][k] for k in ks]; bars=ax.bar(x+(j-0.5)*w,v,w-0.03,color=C[j],hatch=H[j],label=name)
    for xi,vi in zip(x+(j-0.5)*w,v): ax.text(xi,vi+0.01,f'{vi:.3f}',ha='center',va='bottom',fontsize=8)
ax.set_xticks(x,labels); ax.set_ylim(0,1.25); ax.set_yticks([0,.2,.4,.6,.8,1.0]); ax.set_ylabel('Score (breaking-change detection)'); ax.legend(frameon=False,loc='upper center',ncol=2)
save(fig,'g_mut_compare')
# naive errors by operator (rate out of trials for that operator)
rows=json.load(open(E+'mutation_results.json')); import collections
n=collections.Counter(r['operator'] for r in rows if r.get('eligible')!=0)
err=m['naiveErrorsByOperator']
ops_sorted=sorted(err,key=lambda k:-err[k]/n[k])
fig,ax=plt.subplots(figsize=(6.2,2.6))
vals=[100*err[k]/n[k] for k in ops_sorted]
ax.barh(range(len(vals)),vals,color=C[1],hatch='///')
for i,v in enumerate(vals): ax.text(v+1,i,f'{v:.0f}%  ({err[ops_sorted[i]]}/{n[ops_sorted[i]]})',va='center',fontsize=8)
ax.set_yticks(range(len(vals)),[k.replace('_',' ').title() for k in ops_sorted]); ax.invert_yaxis(); ax.set_xlim(0,150); ax.set_xticks([0,20,40,60,80,100]); ax.set_xlabel('Naive classifier error rate (%) ; sma error rate is 0% for every operator')
save(fig,'g_mut_naive_errors')
# ---- compound
c=json.load(open(E+'compound_summary.json')); K=sorted(int(k) for k in c)
fig,ax=plt.subplots(figsize=(6.2,3.4))
for i,(key,l) in enumerate([('labelP','Label precision'),('labelR','Label recall'),('exactTrials','Trials with exact label set'),('opRecallRaw','Broken-operation recall (raw)')]):
    ax.plot(K,[c[str(k)][key] for k in K],marker='os^D'[i],color=C[i],label=l)
ax.plot(K,[c[str(k)]['opRecallAdjusted'] for k in K],'--',color='#555',label='Broken-operation recall (net-effect adjusted)')
ax.set_xlabel('Simultaneous changes per release k'); ax.set_ylabel('Score'); ax.set_ylim(0.55,1.02); ax.set_xticks(K); ax.legend(frameon=False,loc='lower left',fontsize=8)
save(fig,'g_compound')
# ---- call-site benchmark (values from device run, csbench_40.json)
res=[('sma AST\n(ts-morph)',1.0,0.6995192307692307,0.8231966053748231),('R1: grep\npath strings',0.7951807228915663,0.47596153846153844,0.5954887218045113),('R2: grep\ncall + path',0.9186602870813397,0.46153846153846156,0.6144000000000001)]
fig,ax=plt.subplots(figsize=(6.2,3.2)); x=np.arange(3); w=0.26
for j,l in enumerate(['Precision','Recall','F1 score']):
    v=[r[j+1] for r in res]; ax.bar(x+(j-1)*w,v,w-0.03,color=C[j],hatch=H[j],label=l)
    for xi,vi in zip(x+(j-1)*w,v): ax.text(xi,vi+0.01,f'{vi:.2f}',ha='center',fontsize=8)
ax.set_xticks(x,[r[0] for r in res]); ax.set_ylim(0,1.15); ax.set_ylabel('Score'); ax.legend(frameon=False,ncol=3,loc='upper right')
save(fig,'g_cs_prf')
cats=['Direct HTTP\ncalls (182)','One-hop\ncallers (109)','Two-hop\ncallers (109)','Computed URL\n(10)','Unsupported\nclient (6)','Non-calls\n(51, lower=better)']
found={'sma AST':[182,109,0,0,0,0],'R1 grep path':[182,0,0,10,6,51],'R2 grep call+path':[182,0,0,10,0,17]}
tot=[182,109,109,10,6,51]
fig,ax=plt.subplots(figsize=(6.4,3.3)); x=np.arange(6); w=0.26
for j,(k,v) in enumerate(found.items()):
    p=[100*a/b for a,b in zip(v,tot)]; ax.bar(x+(j-1)*w,p,w-0.03,color=C[j],hatch=H[j],label=k)
ax.text(3-0.26,4,'flagged as\nunresolved\n(10/10)',ha='center',fontsize=7)
ax.set_xticks(x,cats,fontsize=8); ax.set_ylabel('Statements reported as call sites (%)'); ax.set_ylim(0,128); ax.set_yticks([0,20,40,60,80,100]); ax.legend(frameon=False,ncol=3,loc='upper center',fontsize=8)
save(fig,'g_cs_bycat')
# ---- demo app tests
fig,ax=plt.subplots(figsize=(6.2,2.8))
lab=['Original code\nvs API v1','Original code\nvs API v2','Patched code\nvs API v2','Patched code\nvs API v1']; p=[4,0,4,3]
b=ax.bar(range(4),p,color=[C[2],C[1],C[2],C[3]],width=0.55)
for i,v in enumerate(p): ax.text(i,v+0.08,f'{v}/4 pass',ha='center',fontsize=9)
ax.set_xticks(range(4),lab); ax.set_ylim(0,4.8); ax.set_ylabel('Tests passing (of 4)')
save(fig,'g_demo_tests')
# ---- unit test durations by file (ms, from spec reporter)
d={'auth':[2.52,0.37,1.63,0.38,0.63],'diff':[97.8,44.9,57.7,34.0,46.2,16.1,17.8,16.2,12.8,10.5],'impact':[2.18,0.35,0.28,0.26,0.30,0.34,0.59,0.22],'inventory':[882.6,461.7,540.5,529.4,493.8,297.9,297.0],'repair':[48.8,26.9,35.8,29.0,32.8,26.5],'report':[18.3,1.6,0.48],'store':[2.7,0.53,13.4,3.65,2.81],'watcher':[12.7,4.9,2.2,1.05,0.48,1.58,1046.6]}
fig,ax=plt.subplots(figsize=(6.2,2.9)); names=list(d); tot=[sum(v) for v in d.values()]
ax.bar(range(len(names)),tot,color=C[0],width=0.6)
for i,(t,nm) in enumerate(zip(tot,names)): ax.text(i,t*1.15,f'{t:.0f} ms\n({len(d[nm])} tests)',ha='center',fontsize=7.5)
ax.set_yscale('log'); ax.set_ylim(0.5,20000); ax.set_xticks(range(len(names)),[n+'.test' for n in names],fontsize=8,rotation=15); ax.set_ylabel('Sum of test durations (ms, log)')
save(fig,'g_unit_durations')
# ---- scan scaling (Machine A)
import collections
dd=collections.defaultdict(list); st={}
for line in open(E+'scan_scale.txt'):
    n,files,stm,ms,p,r=line.split(); dd[int(files)].append(float(ms)); st[int(files)]=int(stm)
F=np.array(sorted(dd)); mn=np.array([min(dd[f]) for f in F]); md=np.array([np.median(dd[f]) for f in F])
b1,b0=np.polyfit(F,mn,1); pred=b0+b1*F; r2=1-((mn-pred)**2).sum()/((mn-mn.mean())**2).sum()
json.dump(dict(files=F.tolist(),min=mn.tolist(),median=md.tolist(),b0=b0,b1=b1,r2=r2,statements=[st[f] for f in F]),open(E+'scan_fit.json','w'),indent=1)
fig,ax=plt.subplots(figsize=(6.2,3.3))
for f in F: ax.plot([f]*len(dd[f]),dd[f],'.',color='#9bbbe6',ms=6)
ax.plot(F,mn,'o',color=C[0],label='Fastest of repeated runs')
xx=np.linspace(0,F.max(),50); ax.plot(xx,b0+b1*xx,color=C[1],label=f'Linear fit t = {b0:.0f} + {b1:.2f} f ms  (R² = {r2:.3f})')
ax.plot([],[],'.',color='#9bbbe6',label='Individual runs')
ax.set_xlabel('Repository size f (source files)'); ax.set_ylabel('AST scan time (ms)'); ax.legend(frameon=False,loc='upper left')
save(fig,'g_scan_scale')
print('scan fit',b0,b1,r2, list(zip(F,mn)))
