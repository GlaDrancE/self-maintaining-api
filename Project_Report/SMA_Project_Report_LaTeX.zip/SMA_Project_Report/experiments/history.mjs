// Longitudinal study: classify every consecutive pair of openapi.yaml versions in a git repo.
import { execFileSync } from 'node:child_process';
import { appendFileSync, writeFileSync } from 'node:fs';
import { parse } from '/home/claude/repo/sma/node_modules/yaml/dist/index.js';
import { resolveRefs } from '/home/claude/repo/sma/src/watcher.mjs';
import { applyRules } from '/home/claude/repo/sma/src/rules.mjs';
import { unexplainedDeltas } from '/home/claude/repo/sma/src/classify.mjs';
const [repo, file, out] = process.argv.slice(2);
const log = execFileSync('git', ['-C', repo, 'log', '--reverse', '--format=%H|%cI|%s', '--', file], { encoding: 'utf8', maxBuffer: 1e8 }).trim().split('\n');
writeFileSync(out, '');
let prev = null, prevMeta = null;
for (const line of log) {
  const [sha, date, ...s] = line.split('|');
  const subject = s.join('|');
  let text;
  try { text = execFileSync('git', ['-C', repo, 'show', `${sha}:${file}`], { encoding: 'utf8', maxBuffer: 5e8 }); } catch { continue; }
  let spec, tParse, tRes;
  try {
    let t = performance.now(); const raw = parse(text, { maxAliasCount: -1 }); tParse = performance.now() - t;
    t = performance.now(); spec = resolveRefs(raw); tRes = performance.now() - t;
  } catch (e) { appendFileSync(out, JSON.stringify({ sha, date, error: String(e.message).slice(0, 200) }) + '\n'); continue; }
  const meta = { sha, date, subject, bytes: text.length, paths: Object.keys(spec.paths ?? {}).length,
    ops: Object.values(spec.paths ?? {}).reduce((n, p) => n + ['get','put','post','delete','patch','head','options','trace'].filter((m) => p && p[m]).length, 0), tParse, tRes };
  if (prev) {
    let t = performance.now(); const hits = applyRules(prev, spec); const tRules = performance.now() - t;
    t = performance.now(); let left = []; try { left = unexplainedDeltas(prev, spec, hits); } catch (e) { left = null; } const tLeft = performance.now() - t;
    const same = (h) => (h.rule === 'RESPONSE_FIELD_TYPE_CHANGED' || h.rule === 'PARAM_TYPE_CHANGED') && JSON.stringify(h.detail.from) === JSON.stringify(h.detail.to);
    const spurious = hits.filter(same).length; const real = hits.filter((h) => !same(h));
    const byRuleReal = {}; for (const h of real) byRuleReal[h.rule] = (byRuleReal[h.rule] ?? 0) + 1;
    const byRule = {}; const bySev = {};
    for (const h of hits) { byRule[h.rule] = (byRule[h.rule] ?? 0) + 1; bySev[h.severity] = (bySev[h.severity] ?? 0) + 1; }
    appendFileSync(out, JSON.stringify({ ...meta, from: prevMeta.sha, fromDate: prevMeta.date, fromPaths: prevMeta.paths, fromOps: prevMeta.ops,
      tRules, tLeft, nHits: hits.length, spurious, byRuleReal, breakingReal: real.filter((h) => h.severity === 'breaking').length, byRule, bySev, leftovers: left === null ? null : left.length,
      breaking: hits.filter((h) => h.severity === 'breaking').map((h) => `${h.rule} ${h.method ?? '-'} ${h.path ?? '-'} ${JSON.stringify(h.detail).slice(0, 80)}`).slice(0, 40), breakingRealList: real.filter((h) => h.severity === 'breaking').map((h) => `${h.rule} ${h.method ?? '-'} ${h.path ?? '-'} ${JSON.stringify(h.detail).slice(0, 100)}`).slice(0, 60) }) + '\n');
  } else appendFileSync(out, JSON.stringify({ ...meta, first: true }) + '\n');
  prev = spec; prevMeta = meta;
}
console.log('done', log.length);
