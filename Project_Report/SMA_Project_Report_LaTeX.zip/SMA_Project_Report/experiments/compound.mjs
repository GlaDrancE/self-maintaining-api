// Mutation benchmark: inject one known change into a real spec, check what each classifier reports.
// Method A = sma rule engine (applyRules + unexplainedDeltas). Method B = naive structural diff
// (remove => breaking, add => safe, change => breaking), the behaviour of a generic JSON diff.
import { readFileSync, writeFileSync } from 'node:fs';
import { parse } from '/home/claude/repo/sma/node_modules/yaml/dist/index.js';
import { resolveRefs } from '/home/claude/repo/sma/src/watcher.mjs';
import { applyRules } from '/home/claude/repo/sma/src/rules.mjs';
import { unexplainedDeltas } from '/home/claude/repo/sma/src/classify.mjs';
import { diff } from '/home/claude/repo/sma/src/diff.mjs';

let seed = 42;
const rnd = () => ((seed = (seed * 1103515245 + 12345) % 2147483648) / 2147483648);
const pick = (a) => a[Math.floor(rnd() * a.length)];
const M = ['get', 'put', 'post', 'delete', 'patch'];
const clone = (x) => structuredClone(x);
const ops = (s) => Object.entries(s.paths).flatMap(([p, it]) => M.filter((m) => it?.[m]).map((m) => ({ p, m, op: it[m], it })));
const unwrap = (sc) => { let s = sc; while (s?.type === 'array' && s.items) s = s.items; return s; };
const jsonSchema = (c) => { const ct = c?.content ?? {}; const k = Object.keys(ct).find((k) => k.includes('json')) ?? Object.keys(ct)[0]; return unwrap(ct[k]?.schema); };
const okResp = (op) => { const c = Object.keys(op.responses ?? {}).filter((x) => /^2\d\d$/.test(x)).sort()[0]; return c ? jsonSchema(op.responses[c]) : null; };
const params = (o) => (o.op.parameters ?? []);
const typed = (props) => Object.entries(props ?? {}).filter(([, v]) => typeof v?.type === 'string' && v.type !== 'array' && v.type !== 'object');
const fresh = (base) => `${base}_${Math.floor(rnd() * 1e6)}`;
const swapType = (t) => (t === 'string' ? 'integer' : 'string');

// Each operator: eligible(o) and apply(spec, o) -> expected [{rule, method, path}] (empty = no change expected)
const OPS = {
  PATH_REMOVED: { sev: 'breaking', el: (o) => true, ap: (s, o) => { delete s.paths[o.p]; return [['PATH_REMOVED', null, o.p]]; } },
  METHOD_REMOVED: { sev: 'breaking', el: (o) => M.filter((m) => o.it[m]).length > 1, ap: (s, o) => { delete s.paths[o.p][o.m]; return [['METHOD_REMOVED', o.m, o.p]]; } },
  REQUIRED_PARAM_ADDED: { sev: 'breaking', el: () => true, ap: (s, o) => { const op = s.paths[o.p][o.m]; (op.parameters ??= []).push({ name: fresh('req'), in: 'query', required: true, schema: { type: 'string' } }); return [['REQUIRED_PARAM_ADDED', o.m, o.p]]; } },
  REQUIRED_BODY_FIELD_ADDED: { sev: 'breaking', rule: 'REQUIRED_PARAM_ADDED', el: (o) => !!jsonSchema(o.op.requestBody)?.properties, ap: (s, o) => { const b = jsonSchema(s.paths[o.p][o.m].requestBody); const n = fresh('field'); b.properties[n] = { type: 'string' }; (b.required ??= []).push(n); return [['REQUIRED_PARAM_ADDED', o.m, o.p]]; } },
  OPTIONAL_PARAM_ADDED: { sev: 'safe', el: () => true, ap: (s, o) => { (s.paths[o.p][o.m].parameters ??= []).push({ name: fresh('opt'), in: 'query', required: false, schema: { type: 'string' } }); return [['OPTIONAL_PARAM_ADDED', o.m, o.p]]; } },
  PARAM_RENAMED: { sev: 'breaking', el: (o) => params(o).some((p) => p.in === 'query'), ap: (s, o) => { const p = pick(s.paths[o.p][o.m].parameters.filter((p) => p.in === 'query')); p.name = fresh(p.name); return [['PARAM_RENAMED', o.m, o.p]]; } },
  PARAM_REMOVED: { sev: 'breaking', el: (o) => params(o).some((p) => p.in === 'query'), ap: (s, o) => { const op = s.paths[o.p][o.m]; const p = pick(op.parameters.filter((p) => p.in === 'query')); op.parameters = op.parameters.filter((x) => x !== p); return [['PARAM_REMOVED', o.m, o.p]]; } },
  PARAM_TYPE_CHANGED: { sev: 'breaking', el: (o) => params(o).some((p) => typeof p.schema?.type === 'string'), ap: (s, o) => { const p = pick(s.paths[o.p][o.m].parameters.filter((p) => typeof p.schema?.type === 'string')); p.schema.type = swapType(p.schema.type); delete p.schema.enum; return [['PARAM_TYPE_CHANGED', o.m, o.p]]; } },
  PARAM_MADE_REQUIRED: { sev: 'breaking', el: (o) => params(o).some((p) => !p.required), ap: (s, o) => { const p = pick(s.paths[o.p][o.m].parameters.filter((p) => !p.required)); p.required = true; return [['PARAM_MADE_REQUIRED', o.m, o.p]]; } },
  RESPONSE_FIELD_REMOVED: { sev: 'breaking', el: (o) => Object.keys(okResp(o.op)?.properties ?? {}).length > 0, ap: (s, o) => { const r = okResp(s.paths[o.p][o.m]); const k = pick(Object.keys(r.properties)); delete r.properties[k]; if (Array.isArray(r.required)) r.required = r.required.filter((x) => x !== k); return [['RESPONSE_FIELD_REMOVED', o.m, o.p]]; } },
  RESPONSE_FIELD_TYPE_CHANGED: { sev: 'breaking', el: (o) => typed(okResp(o.op)?.properties).length > 0, ap: (s, o) => { const r = okResp(s.paths[o.p][o.m]); const [k, v] = pick(typed(r.properties)); v.type = swapType(v.type); delete v.enum; return [['RESPONSE_FIELD_TYPE_CHANGED', o.m, o.p]]; } },
  RESPONSE_FIELD_ADDED: { sev: 'safe', el: (o) => !!okResp(o.op)?.properties, ap: (s, o) => { okResp(s.paths[o.p][o.m]).properties[fresh('new')] = { type: 'string' }; return [['RESPONSE_FIELD_ADDED', o.m, o.p]]; } },
  ENUM_VALUE_REMOVED: { sev: 'breaking', el: (o) => Object.values(okResp(o.op)?.properties ?? {}).some((v) => v?.enum?.length > 1), ap: (s, o) => { const v = pick(Object.values(okResp(s.paths[o.p][o.m]).properties).filter((v) => v?.enum?.length > 1)); v.enum = v.enum.slice(1); return [['ENUM_VALUE_REMOVED', o.m, o.p]]; } },
  ENUM_VALUE_ADDED: { sev: 'safe', el: (o) => Object.values(okResp(o.op)?.properties ?? {}).some((v) => Array.isArray(v?.enum)), ap: (s, o) => { const v = pick(Object.values(okResp(s.paths[o.p][o.m]).properties).filter((v) => Array.isArray(v?.enum))); v.enum = [...v.enum, fresh('val')]; return [['ENUM_VALUE_ADDED', o.m, o.p]]; } },
  PATH_DEPRECATED: { sev: 'warning', el: (o) => !o.op.deprecated, ap: (s, o) => { s.paths[o.p][o.m].deprecated = true; return [['PATH_DEPRECATED', o.m, o.p]]; } },
  PATH_ADDED: { sev: 'safe', el: () => true, ap: (s, o) => { const np = `${o.p}/${fresh('sub')}`; s.paths[np] = { get: clone(s.paths[o.p][o.m]) }; return [['PATH_ADDED', null, np]]; } },
  METHOD_ADDED: { sev: 'safe', el: (o) => M.some((m) => !o.it[m]), ap: (s, o) => { const m = M.find((m) => !s.paths[o.p][m]); s.paths[o.p][m] = clone(s.paths[o.p][o.m]); return [['METHOD_ADDED', m, o.p]]; } },
  AUTH_SCHEME_CHANGED: { sev: 'breaking', global: true, el: () => true, ap: (s) => { const sc = s.components?.securitySchemes; const k = Object.keys(sc)[0]; sc[k] = { type: 'http', scheme: sc[k].scheme === 'bearer' ? 'basic' : 'bearer' }; return [['AUTH_SCHEME_CHANGED', null, null]]; } },
  // noise: must produce nothing
  NOISE_DESCRIPTION: { sev: 'none', el: () => true, ap: (s, o) => { s.paths[o.p][o.m].description = 'Edited prose ' + rnd(); return []; } },
  NOISE_SUMMARY: { sev: 'none', el: () => true, ap: (s, o) => { s.paths[o.p][o.m].summary = 'New summary ' + rnd(); return []; } },
  NOISE_REORDER_PARAMS: { sev: 'none', el: (o) => params(o).length > 1, ap: (s, o) => { s.paths[o.p][o.m].parameters.reverse(); return []; } },
  NOISE_REORDER_ENUM: { sev: 'none', el: (o) => Object.values(okResp(o.op)?.properties ?? {}).some((v) => v?.enum?.length > 1), ap: (s, o) => { pick(Object.values(okResp(s.paths[o.p][o.m]).properties).filter((v) => v?.enum?.length > 1)).enum.reverse(); return []; } },
  NOISE_INFO_VERSION: { sev: 'none', global: true, el: () => true, ap: (s) => { s.info.version = '9.9.' + Math.floor(rnd() * 100); return []; } },
  NOISE_EXAMPLE: { sev: 'none', el: (o) => !!okResp(o.op)?.properties, ap: (s, o) => { okResp(s.paths[o.p][o.m]).example = { x: rnd() }; return []; } },
};

// Compound mutations: k independent changes in one release, possibly on the same operation.
const load = (f) => resolveRefs(parse(readFileSync(f, 'utf8'), { maxAliasCount: -1 }));
const bases = process.argv.slice(3).map((f) => [f.split('/').at(-1), load(f)]);
const trials = Number(process.argv[2]);
const names = Object.keys(OPS).filter((n) => !n.startsWith('NOISE_') ); 
const noise = Object.keys(OPS).filter((n) => n.startsWith('NOISE_'));
const out = [];
for (const [bname, base] of bases) {
  for (const k of [1, 2, 3, 4, 6, 8]) {
    for (let t = 0; t < trials; t++) {
      const after = clone(base);
      let expected = []; const brokenOps = new Set(); const removedPaths = new Set(); const removedOps = new Set(); const touched = new Map();
      let applied = 0, guard = 0;
      while (applied < k && guard++ < 50) {
        const opName = rnd() < 0.15 ? pick(noise) : pick(names); const def = OPS[opName];
        if (opName === 'AUTH_SCHEME_CHANGED' && !Object.keys(after.components?.securitySchemes ?? {}).length) continue;
        const elig = ops(after).filter(def.el).filter((o) => !removedPaths.has(o.p));
        if (!elig.length) continue;
        const o = pick(elig);
        const exp = def.ap(after, o).map(([r, m, p]) => `${r} ${m ? m.toUpperCase() : '-'} ${p ?? '-'}`);
        if (opName === 'PATH_REMOVED') { removedPaths.add(o.p); expected = expected.filter((e) => !e.endsWith(' ' + o.p) || e.startsWith('PATH_ADDED')); }
        if (opName === 'METHOD_REMOVED') { expected = expected.filter((e) => !e.endsWith(` ${o.m.toUpperCase()} ${o.p}`)); }
        expected.push(...exp);
        const opKey = def.global ? '*' : `${o.m.toUpperCase()} ${o.p}`;
        touched.set(opKey, (touched.get(opKey) ?? 0) + 1);
        if (def.sev === 'breaking') brokenOps.add(opName === 'PATH_REMOVED' ? `* ${o.p}` : opKey);
        applied++;
      }
      const hits = applyRules(base, after);
      const left = unexplainedDeltas(base, after, hits);
      const got = hits.map((h) => `${h.rule} ${h.method ?? '-'} ${h.path ?? '-'}`);
      // multiset match
      const pool = [...got]; let tp = 0;
      for (const e of expected) { const i = pool.indexOf(e); if (i > -1) { tp++; pool.splice(i, 1); } }
      const fp = pool.length, fn = expected.length - tp;
      // severity level: was a breaking change detected for every broken operation?
      const smaBrokenOps = new Set(hits.filter((h) => h.severity === 'breaking').map((h) => (h.rule === 'PATH_REMOVED' ? `* ${h.path}` : h.path ? `${h.method} ${h.path}` : '*')));
      const exists = (b) => { const [m, p] = b.split(' '); return m === '*' ? true : !!base.paths[p]?.[m.toLowerCase()]; };
      const norm = new Set([...brokenOps].filter(exists).map((b) => { const [m, p] = b.split(' '); return m !== '*' && !after.paths[p] ? `* ${p}` : b; }));
      brokenOps.clear(); for (const b of norm) brokenOps.add(b);
      let opTP = 0; const missDetail = [];
      for (const b of brokenOps) { if (smaBrokenOps.has(b)) { opTP++; continue; }
        const [m, p] = b.split(' ');
        const bOp = m === '*' ? (p ? base.paths[p] : base.components) : base.paths[p]?.[m.toLowerCase()];
        const aOp = m === '*' ? (p ? after.paths[p] : after.components) : after.paths[p]?.[m.toLowerCase()];
        const d = diff(bOp ?? {}, aOp ?? {}).filter((x) => !/(description|summary|example)/.test(x.pointer));
        missDetail.push({ op: b, netDeltas: d.length, addsOnly: d.every((x) => x.op === 'add' && !JSON.stringify(x.after ?? {}).includes('"required":true') && !/deprecated|required/.test(x.pointer)), hitsHere: hits.filter((h) => `${h.method} ${h.path}` === b).map((h) => h.rule + ':' + h.severity), sample: d.slice(0, 3).map((x) => x.op + ' ' + x.pointer) }); }
      const collisions = [...touched.values()].filter((v) => v > 1).length;
      out.push({ base: bname, k, applied, expected: expected.length, got: got.length, tp, fp, fn, leftovers: left.length, brokenOps: brokenOps.size, opTP, smaBrokenOps: smaBrokenOps.size, collisions, missDetail,
        errors: fp || fn ? { exp: expected.filter((e) => !got.includes(e)), extra: pool } : null });
    }
  }
}
writeFileSync('/home/claude/exp/compound_results.json', JSON.stringify(out));
console.log(out.length);
