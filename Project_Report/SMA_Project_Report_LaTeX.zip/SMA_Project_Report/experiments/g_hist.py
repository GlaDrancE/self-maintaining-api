import json, numpy as np, collections, datetime as dt
from style import *
E='/home/claude/exp/'
R=[json.loads(l) for l in open(E+'openai_history.jsonl')]
V=[r for r in R if 'error' not in r]; P=[r for r in R if 'from' in r]; ERR=[r for r in R if 'error' in r]
d=lambda s: dt.datetime.fromisoformat(s.replace('Z','+00:00'))
# growth
fig,axs=plt.subplots(2,1,figsize=(6.2,4.4),sharex=True)
T=[d(r['date']) for r in V]
axs[0].plot(T,[r['ops'] for r in V],color=C[0],label='Operations'); axs[0].plot(T,[r['paths'] for r in V],color=C[1],label='Paths')
axs[0].set_ylabel('Count'); axs[0].legend(frameon=False,loc='upper left')
axs[1].plot(T,[r['bytes']/1e6 for r in V],color=C[2]); axs[1].set_ylabel('openapi.yaml (MB)'); axs[1].set_xlabel('Commit date')
save(fig,'g_hist_growth')
# classify breaking-real findings
def cls(item):
    rule=item.split()[0]
    if rule in ('PARAM_TYPE_CHANGED','RESPONSE_FIELD_TYPE_CHANGED'):
        import re
        js=item[item.index('{'):]
        mf=re.search(r'"from":(\[[^\]]*\]|"[^"]*")',js); mt=re.search(r'"to":(\[[^\]]*\]|"[^"]*")',js)
        trunc = not js.rstrip().endswith('}')
        if trunc and not (mf and mt): return 'type: detail truncated'
        f=json.loads(mf.group(1)) if mf else None; t=json.loads(mt.group(1)) if mt else None
        if f is None or t is None: return 'type: composition (anyOf/oneOf)'
        isn=lambda x: isinstance(x,list) and 'null' in x
        if isn(f)!=isn(t): return 'type: nullability'
        return 'type: real type change'
    return 'structural (removal, required, rename, enum)'
cc=collections.Counter()
for r in P:
    for it in r.get('breakingRealList',[]): cc[cls(it)]+=1
# quarterly counts
q=collections.defaultdict(lambda: collections.Counter())
for r in P:
    t=d(r['date']); key=f"{t.year}Q{(t.month-1)//3+1}"
    q[key]['breaking']+=r['breakingReal']; q[key]['safe']+=r['bySev'].get('safe',0); q[key]['warning']+=r['bySev'].get('warning',0); q[key]['spurious']+=r['spurious']; q[key]['commits']+=1
ks=sorted(q); y0,q0=int(ks[0][:4]),int(ks[0][5]); y1,q1=int(ks[-1][:4]),int(ks[-1][5])
keys=[f'{y}Q{qq}' for y in range(y0,y1+1) for qq in range(1,5) if (y,qq)>=(y0,q0) and (y,qq)<=(y1,q1)]
fig,ax=plt.subplots(figsize=(6.4,3.2)); x=np.arange(len(keys)); w=0.38
ax.bar(x-w/2,[q[k]['breaking'] for k in keys],w-0.04,color=C[1],hatch='///',label='Breaking findings (excluding identity artifacts)')
ax.bar(x+w/2,[q[k]['safe'] for k in keys],w-0.04,color=C[2],label='Safe (additive) findings')
ax.set_yscale('symlog',linthresh=10); ax.set_xticks(x,keys,rotation=60,fontsize=7.5)
for i,k in enumerate(keys):
    if q[k]['commits']==0: ax.text(i,0.6,'no\ncommits',ha='center',fontsize=5.5,color='#777'); ax.set_ylabel('Findings per quarter (symlog)'); ax.legend(frameon=False,fontsize=8,loc='upper left')
save(fig,'g_hist_quarterly')
# rule distribution
rr=collections.Counter()
for r in P:
    for k,v in r['byRuleReal'].items(): rr[k]+=v
sp=sum(r['spurious'] for r in P)
items=rr.most_common()
fig,ax=plt.subplots(figsize=(6.2,3.8))
sev={'PATH_REMOVED':1,'METHOD_REMOVED':1,'REQUIRED_PARAM_ADDED':1,'PARAM_REMOVED':1,'PARAM_RENAMED':1,'PARAM_TYPE_CHANGED':1,'PARAM_MADE_REQUIRED':1,'RESPONSE_FIELD_REMOVED':1,'RESPONSE_FIELD_TYPE_CHANGED':1,'ENUM_VALUE_REMOVED':1,'AUTH_SCHEME_CHANGED':1,'PATH_DEPRECATED':0}
for i,(k,v) in enumerate(items):
    s=sev.get(k,-1); ax.barh(i,v,color=C[1] if s==1 else (C[3] if s==0 else C[2]),hatch='///' if s==1 else '')
    ax.text(v*1.05+0.5,i,str(v),va='center',fontsize=8)
ax.set_yticks(range(len(items)),[k for k,_ in items],fontsize=8); ax.invert_yaxis(); ax.set_xscale('log'); ax.set_xlabel('Findings over the whole history (log scale)')
from matplotlib.patches import Patch
ax.legend(handles=[Patch(facecolor=C[1],hatch='///',label='breaking'),Patch(facecolor=C[3],label='warning'),Patch(facecolor=C[2],label='safe')],frameon=False,loc='lower right')
save(fig,'g_hist_rules')
# timing vs size
B=np.array([r['bytes'] for r in P])/1e6; tt=np.array([r['tParse']+r['tRes']+r['tRules']+r['tLeft'] for r in P])/1000
b1,b0=np.polyfit(B,tt,1); pred=b0+b1*B; r2=1-((tt-pred)**2).sum()/((tt-tt.mean())**2).sum()
fig,ax=plt.subplots(figsize=(6.2,3.2)); ax.plot(B,tt,'.',color=C[0],ms=5,label='One version (parse + resolve + rules + leftovers)')
xx=np.linspace(0,B.max(),50); ax.plot(xx,b0+b1*xx,color=C[1],label=f'Linear fit t = {b0:.2f} + {b1:.2f}·MB s  (R² = {r2:.3f})')
ax.set_xlabel('Size of openapi.yaml (MB)'); ax.set_ylabel('Processing time (s)'); ax.legend(frameon=False,loc='upper left',fontsize=8)
save(fig,'g_hist_time')
first31=next((r for r in P if r['spurious']>0),None)
out=dict(lines=len(R),versions=len(V),pairs=len(P),errors=len(ERR),first=V[0]['date'],last=V[-1]['date'],firstPaths=V[0]['paths'],firstOps=V[0]['ops'],lastPaths=V[-1]['paths'],lastOps=V[-1]['ops'],lastBytes=V[-1]['bytes'],
 firstBytes=V[0]['bytes'],pairsNoChange=sum(1 for r in P if r['nHits']==0 and not r['leftovers']),pairsRulesOnly=sum(1 for r in P if not r['leftovers']),pairsWithLeftovers=sum(1 for r in P if r['leftovers']),totalLeftovers=sum(r['leftovers'] or 0 for r in P),
 pairsWithBreakingReal=sum(1 for r in P if r['breakingReal']>0),breakingRealTotal=sum(r['breakingReal'] for r in P),rawHits=sum(r['nHits'] for r in P),spurious=sp,pairsSpurious=sum(1 for r in P if r['spurious']>0),
 firstSpurious=(first31['date'],first31['subject']) if first31 else None,byRuleReal=dict(rr),classes=dict(cc),timeFit=dict(b0=b0,b1=b1,r2=r2),maxTime=float(tt.max()),medianTime=float(np.median(tt)),
 errorsList=[(e['date'],e['error'][:60]) for e in ERR],
 sevTotals={s:sum(r['bySev'].get(s,0) for r in P) for s in ['breaking','warning','safe']})
json.dump(out,open(E+'history_summary.json','w'),indent=1); print(json.dumps(out,indent=1)[:3000])
