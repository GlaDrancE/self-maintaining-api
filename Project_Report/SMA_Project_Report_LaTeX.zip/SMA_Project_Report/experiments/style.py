import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager as fm
fm.fontManager.addfont('/usr/share/fonts/truetype/liberation/LiberationSerif-Regular.ttf')
fm.fontManager.addfont('/usr/share/fonts/truetype/liberation/LiberationSerif-Bold.ttf')
C = ['#2a78d6', '#eb6834', '#1baf7a', '#eda100', '#e87ba4']
H = ['', '///', '...', 'xx']
plt.rcParams.update({'font.family': 'Liberation Serif', 'font.size': 10, 'axes.titlesize': 10, 'axes.labelsize': 10,
  'legend.fontsize': 9, 'xtick.labelsize': 9, 'ytick.labelsize': 9, 'axes.spines.top': False, 'axes.spines.right': False,
  'axes.edgecolor': '#555', 'axes.grid': True, 'grid.color': '#e3e3e3', 'grid.linewidth': 0.6, 'axes.axisbelow': True,
  'lines.linewidth': 2, 'lines.markersize': 6, 'savefig.bbox': 'tight', 'savefig.dpi': 200, 'hatch.linewidth': 0.6, 'hatch.color': 'white'})
OUT = '/home/claude/report/figures/'
def save(fig, name): fig.savefig(OUT + name + '.pdf'); plt.close(fig)
