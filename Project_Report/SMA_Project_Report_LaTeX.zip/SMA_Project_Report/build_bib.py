#!/usr/bin/env python3
"""Build refs.tex (a thebibliography) from refs_raw.bib + refs_extra.bib.

Entries are listed in order of first citation (read from main.aux), in the format the
Report Guidelines ask for:  Author, "Title", Journal/Transactions/Book, Edition/Volume,
Publisher, Year, pp. __.   Web pages carry the full address and the access date.
Run:  pdflatex main  ->  python3 build_bib.py  ->  pdflatex main  ->  pdflatex main
"""
import re, sys, pathlib

HERE = pathlib.Path(__file__).parent

def parse_bib(text):
    entries = {}
    i = 0
    while True:
        m = re.compile(r'@(\w+)\s*\{\s*([^,\s]+)\s*,').search(text, i)
        if not m:
            break
        typ, key = m.group(1).lower(), m.group(2)
        j, depth = m.end(), 1
        while depth and j < len(text):
            depth += {'{': 1, '}': -1}.get(text[j], 0)
            j += 1
        body = text[m.end():j - 1]
        fields, k = {}, 0
        while True:
            fm = re.compile(r'\s*(\w+)\s*=\s*').match(body, k)
            if not fm:
                break
            name, k = fm.group(1).lower(), fm.end()
            if body[k] == '{':
                d, s = 1, k + 1
                k += 1
                while d:
                    d += {'{': 1, '}': -1}.get(body[k], 0)
                    k += 1
                val = body[s:k - 1]
            else:
                vm = re.compile(r'[^,]+').match(body, k)
                val, k = vm.group(0).strip(), vm.end()
            fields[name] = ' '.join(val.split())
            cm = re.compile(r'\s*,').match(body, k)
            if cm:
                k = cm.end()
        entries[key] = (typ, fields)
        i = j
    return entries

def strip_braces(s):
    return s.replace('{', '').replace('}', '')

def fmt_names(s):
    if s.startswith('{') and s.endswith('}'):
        return strip_braces(s)
    names = [n.strip() for n in re.split(r'\s+and\s+', s)]
    out = []
    for n in names:
        if n == 'others':
            out.append('et al.')
            continue
        if ',' in n:
            last, first = [p.strip() for p in n.split(',', 1)]
        else:
            parts = n.split()
            last, first = parts[-1], ' '.join(parts[:-1])
        initials = ' '.join(p[0] + '.' for p in re.split(r'[\s]+', strip_braces(first)) if p and p[0].isalpha())
        initials = re.sub(r'(\w)\.-', r'\1.-', initials)
        out.append((initials + ' ' + strip_braces(last)).strip())
    if out and out[-1] == 'et al.':
        return ', '.join(out[:-1]) + r' \textit{et al.}'
    if len(out) > 6:
        return ', '.join(out[:3]) + r' \textit{et al.}'
    if len(out) == 1:
        return out[0]
    return ', '.join(out[:-1]) + ' and ' + out[-1]

def pages(p):
    return p.replace('--', '-')

def accessed(note):
    m = re.search(r'Accessed:\s*(\d{4})-(\d{2})-(\d{2})', note or '')
    if not m:
        return None
    months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December']
    return f'{int(m.group(3))} {months[int(m.group(2)) - 1]} {m.group(1)}'

def fmt(key, typ, f):
    au = fmt_names(f.get('author') or f.get('editor') or '')
    if f.get('editor') and not f.get('author'):
        au += ' (Eds.)'
    title = f.get('title', '')
    parts = [au, f'``{title}\'\'']
    url = None
    if 'howpublished' in f:
        um = re.search(r'\\url\{([^}]*)\}', f['howpublished'])
        url = um.group(1) if um else None
    url = url or f.get('url')
    if typ == 'article':
        parts.append(r'\textit{' + f.get('journal', '') + '}')
        vol = f.get('volume')
        if vol:
            parts.append('Vol. ' + vol + (f', No. {f["number"]}' if f.get('number') else ''))
        if f.get('publisher'):
            parts.append(f['publisher'])
        parts.append(f.get('year', ''))
        if f.get('pages'):
            parts.append('pp. ' + pages(f['pages']))
    elif typ == 'inproceedings':
        parts.append(r'\textit{' + f.get('booktitle', '') + '}')
        if f.get('series'):
            parts.append(f['series'] + (f', Vol. {f["volume"]}' if f.get('volume') else ''))
        if f.get('publisher'):
            parts.append(f['publisher'])
        parts.append(f.get('year', ''))
        if f.get('pages'):
            parts.append('pp. ' + pages(f['pages']))
    elif typ == 'book':
        b = r'\textit{' + title + '}'
        parts = [au, b]
        if f.get('edition'):
            parts.append(f['edition'] + ' Edition')
        parts.append(f.get('publisher', ''))
        parts.append(f.get('year', ''))
        if f.get('isbn'):
            parts.append('ISBN ' + f['isbn'])
    elif typ == 'phdthesis':
        parts.append('Ph.D. Dissertation, ' + f.get('school', ''))
        parts.append(f.get('year', ''))
    elif typ == 'techreport':
        t = f.get('type', 'Technical Report')
        parts.append(r'\textit{' + (t + ' ' + f.get('number', '')).strip() + '}')
        parts.append(f.get('institution', ''))
        parts.append(f.get('year', ''))
    else:  # misc: preprints and web pages
        if f.get('eprint'):
            parts.append(r'\textit{arXiv preprint arXiv:' + f['eprint'] + '}')
        if f.get('year'):
            parts.append(f['year'])
    s = ', '.join(p for p in parts if p) + '.'
    if f.get('doi'):
        s += r' DOI: \url{https://doi.org/' + f['doi'] + '}.'
    elif url:
        s += r' Available: \url{' + url + '}'
        acc = accessed(f.get('note')) or '21 October 2026'
        s += f' (accessed {acc}).'
    if url and f.get('doi') and accessed(f.get('note')):
        s += f' Accessed {accessed(f.get("note"))}.'
    return s.replace('--', '-').replace('~', r'\textasciitilde{}') if False else s.replace('--', '-')

def main():
    bib = {}
    for name in ['refs_raw.bib', 'refs_extra.bib']:
        bib.update(parse_bib((HERE / name).read_text()))
    aux = (HERE / 'main.aux').read_text() if (HERE / 'main.aux').exists() else ''
    order = []
    for m in re.finditer(r'\\citation\{([^}]*)\}', aux):
        for k in m.group(1).split(','):
            k = k.strip()
            if k and k not in order:
                order.append(k)
    missing = [k for k in order if k not in bib]
    if missing:
        print('MISSING KEYS:', missing, file=sys.stderr)
    lines = [r'\begin{thebibliography}{99}', r'\addtolength{\itemsep}{-2pt}', r'\small']
    for k in order:
        if k in bib:
            typ, f = bib[k]
            lines.append(r'\bibitem{' + k + '} ' + fmt(k, typ, f))
    lines.append(r'\end{thebibliography}')
    (HERE / 'refs.tex').write_text('\n'.join(lines) + '\n')
    print(f'{len(order)} references written; {len(bib)} available')

main()
