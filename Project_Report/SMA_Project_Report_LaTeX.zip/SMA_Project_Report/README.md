# Major Project Report: Self-Maintaining API Integrations (sma)

LaTeX source of the B.Tech (CSE) project report, written to the department's Report Guidelines
(A4; margins left 1.5in, right 0.5in, top 1in, bottom 1in; Times; 1.5 line spacing; chapter
headings ALL CAPITAL 14pt; figure titles below and left aligned; table titles above and left
aligned; small roman page numbers from the List of Abbreviations; page numbers top right, chapter
first pages bottom centre, Chapter 1 first page unnumbered; references in order of use).

## Fill in your details (1 minute)

Open `main.tex` and edit only the block marked **STUDENT AND INSTITUTE DETAILS**:
student names and roll numbers, guide, HOD, principal, department, institute, city, university,
academic year, submission year and the institute mission statement.

Put the college logo next to `main.tex` as `logo.png` (or `logo.jpg`). Until then a placeholder box
is printed on the cover.

## Compile

```
pdflatex main
python3 build_bib.py      # builds refs.tex in order of first citation
pdflatex main
pdflatex main
```

On Overleaf: upload the whole folder, set the compiler to pdfLaTeX, and compile. `refs.tex` is
already generated, so `build_bib.py` is only needed if you add or remove citations.

## Folder contents

| Path | What it is |
|---|---|
| `main.tex` | Preamble, formatting rules, your details, document order |
| `chapters/` | Front matter, Chapters 1 to 5, Contributions, Appendices, Acknowledgement |
| `figures/` | All figures, graphs (PDF) and screenshots (PNG) |
| `refs_raw.bib`, `refs_extra.bib` | Verified references (all checked on 21 Oct 2026) |
| `build_bib.py`, `refs.tex` | Reference list builder and its output |
| `experiments/` | Scripts that produced every number in Chapter 4, plus the result files |
